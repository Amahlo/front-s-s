---
name: Warm Ledger Minimal
colors:
  surface: '#fef8f3'
  surface-dim: '#ded9d4'
  surface-bright: '#fef8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f3ee'
  surface-container: '#f2ede8'
  surface-container-high: '#ece7e2'
  surface-container-highest: '#e6e2dd'
  on-surface: '#1d1b19'
  on-surface-variant: '#4e4543'
  inverse-surface: '#32302d'
  inverse-on-surface: '#f5f0eb'
  outline: '#7f7572'
  outline-variant: '#d1c4c1'
  surface-tint: '#635d5c'
  primary: '#141010'
  on-primary: '#ffffff'
  primary-container: '#292524'
  on-primary-container: '#928c8a'
  inverse-primary: '#cdc5c3'
  secondary: '#446554'
  on-secondary: '#ffffff'
  secondary-container: '#c3e8d2'
  on-secondary-container: '#486a58'
  tertiary: '#00131f'
  on-tertiary: '#ffffff'
  tertiary-container: '#07293a'
  on-tertiary-container: '#7491a6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e9e1df'
  primary-fixed-dim: '#cdc5c3'
  on-primary-fixed: '#1e1b1a'
  on-primary-fixed-variant: '#4b4644'
  secondary-fixed: '#c6ebd5'
  secondary-fixed-dim: '#aacfba'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#2c4d3d'
  tertiary-fixed: '#c8e6fe'
  tertiary-fixed-dim: '#adcae1'
  on-tertiary-fixed: '#001e2e'
  on-tertiary-fixed-variant: '#2d4a5d'
  background: '#fef8f3'
  on-background: '#1d1b19'
  surface-variant: '#e6e2dd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system blends Scandinavian minimalism with warm editorial tactility, tailored for high-frequency point-of-sale (POS) and boutique financial tracking. Designed for small business proprietors, specialty retailers, and modern service professionals, the interface strips away the cold, clinical stress typical of fintech software in favor of calm clarity and purposeful warmth.

The aesthetic pairs organic, soft-tinted surfaces with razor-sharp accounting hierarchy. Rather than sterile white sheets and aggressive neon feedback alerts, the experience mimics fine Japanese paper stock, subtle letterpress framing, and gentle chromatic coding. The emotional tone is grounded, discreet, reliable, and unhurried—instilling confidence during fast-paced transactions without visual fatigue.

## Colors

The palette establishes an organic tonal baseline paired with high-legibility charcoal typography and functional, pastel-toned semantic accents.

### Canvas & Surface Hierarchy
- **Base Canvas (`#F5F0EB` / `#FAF7F2`):** Primary canvas backgrounds use `#FAF7F2` for maximum brightness without blue light glare. Screen-level base framing shifts to `#F5F0EB`.
- **Card & Container Surfaces (`#FFFFFF` to `#FDFBF7`):** Elevated surfaces use pristine, warm off-white tones to define touch targets cleanly.
- **Sunken / Wells (`#EFE8DF`):** Inset states, table headers, and input backgrounds sit on `#EFE8DF` to create clear mechanical wells.
- **Structural Outlines (`#E7DEC8` / `#E2D9CE`):** Soft, low-contrast borders separate adjacent zones without relying on heavy lines.

### Functional & Transactional Pastel Accents
- **Sales & Inflow (`#6B8E7B` / tint `#E8EFEA`):** Soft pastel sage green designating completed sales, settled revenue, and positive balance adjustments.
- **Payments & Transfers (`#7693A8` / tint `#EAF0F4`):** Soft pastel slate/sky blue indicating outbound payment queues, card settlement paths, and verified merchant transfers.
- **Credit & Loans (`#C88A72` / tint `#F8EDE8`):** Warm pastel peach/coral signifying active credit terms, pay-later installments, and pending loan liabilities.
- **Close & Termination Actions (`#B86B64` / tint `#F6EBEA`):** Muted pastel rose/terracotta used exclusively for session closures, voided slips, terminal locks, and critical cancellation vectors.

### Typography & Contrast
- **Primary Ink (`#1C1917`):** Deep charcoal stone ensures strict WCAG AAA contrast across all light surfaces for numerical figures and ledger lines.
- **Muted Ink (`#57534E`):** Secondary metadata, inactive states, and structural hints remain sharp yet subordinate.

## Typography

The typography couples the humanized geometry of Plus Jakarta Sans with the tabular rigor of JetBrains Mono. 

- **Display & Headings:** Plus Jakarta Sans provides friendly yet immaculate structure. Letter-spacing tightens progressively as headline scale increases to keep currency numbers and summary totals visually dense.
- **Body & Captions:** Handled in medium-weight Plus Jakarta Sans to sustain effortless legibility under varying retail lighting environments.
- **Financial & Data Labels:** All currency breakdowns, item counts, SKU identifiers, order timestamps, and receipt metadata utilize JetBrains Mono. This eliminates digit shifting during rapid calculations, preserves column alignment across ledger tables, and gives the POS operational authenticity.

## Layout & Spacing

The system implements a fluid, touch-optimized grid anchored around comfortable thumb zones and split-screen cash register interfaces.

### Grid Principles & Breakpoints
- **Mobile (`< 600px`):** Single-column stacked stream. 16px lateral canvas margins, 12px gutters. Primary transactional triggers fix to a floating bottom container.
- **Tablet / Counter POS (`600px - 1024px`):** Asymmetrical 2-column register layout (60% item catalogue/keypad, 40% active receipt and subtotal bill slip). 24px margins, 16px gutters.
- **Desktop / Backoffice (`> 1024px`):** 12-column layout capped at 1280px max-width, maintaining structured density with multi-period ledger overviews.

### Rhythm
Component internals follow a disciplined 4px base increment. Padding expands generously along horizontal axes for easy physical tap indexing on mobile touchscreens, while vertical spacing remains compact to keep transaction items visible without unnecessary scrolling.

## Elevation & Depth

Visual hierarchy prioritizes tactile paper layers and subtle tonal containment over stark drop shadows.

1. **Base Foundation (Level 0):** Pure natural parchment tone (`#FAF7F2` or `#F5F0EB`) without shadows.
2. **Structural Sheets (Level 1):** Cards, list containers, and bill panels sit on `#FFFFFF` or `#FDFBF7`, delineated by a 1px solid border in `#E7DEC8`. A barely perceptible ambient drop: `0px 2px 8px -2px rgba(41, 37, 36, 0.04)`.
3. **Interactive Overlays & Drawers (Level 2):** Payment terminals, item modulators, and cash drawers lift above the register canvas using a warm-tinted diffused shadow: `0px 12px 28px -6px rgba(41, 37, 36, 0.08), 0px 4px 10px -2px rgba(41, 37, 36, 0.03)` with a hairline border `#DECDBB`.
4. **Modals & Keypad Popovers (Level 3):** Modal screens apply a warm scrim backdrop blur (`rgba(245, 240, 235, 0.72)` with `backdrop-filter: blur(8px)`) beneath a distinct high-ground card framed in `#D8C8B4`.

## Shapes

The interface embraces a balanced rounded profile (`0.5rem` / `8px` baseline). 

- **Small Components (Inputs, Chips, Table Rows):** Fixed at `8px` radius, giving inputs a structured architectural frame.
- **Cards, Panels, and Containers (`rounded-lg`):** Styled at `16px` (`1rem`), creating approachable, sheet-like enclosures that soften dense numerical tables.
- **Sheets, Drawers, and Floating Modal Slips (`rounded-xl`):** Radius set to `24px` (`1.5rem`) on top edges to simulate rounded paper stationery pads.
- **Pills:** Full circular rounding (`9999px`) is reserved solely for categorical transaction status badges (e.g., "Settled", "Pending Cashier") and avatar tokens.

## Components

### Buttons
- **Primary Transaction Button:** Background `#292524`, foreground `#FAF7F2`, font weight 600. Height 48px on mobile for reliable touch capture.
- **Functional Pastel Actions:** Soft tinted backgrounds with darker text for specific flows:
  - *Add to Sale:* `#E8EFEA` background, `#2B4E3B` text.
  - *Process Payment:* `#EAF0F4` background, `#2F4D62` text.
  - *Apply Loan/Credit:* `#F8EDE8` background, `#693A27` text.
  - *Close Shift / Void:* `#F6EBEA` background, `#672923` text.
- **Ghost & Secondary:** Background transparent, 1px border `#E2D9CE`, foreground `#1C1917`. Active state settles to `#EFE8DF`.

### Cards & Ledger Blocks
- Enclosed with 1px border `#E7DEC8` on warm white (`#FFFFFF`) surfaces.
- Segmented sub-rows inside cards use subtle divider lines (`#F2EBE1`) without full container breaks.
- Financial totalizer cards display the primary balance in `headline-xl` Plus Jakarta Sans accompanied by monospaced breakdown tallies in JetBrains Mono.

### Input Fields & Keypads
- **Form Fields:** Height 44px, background `#FAF7F2`, border 1px solid `#E2D9CE`. Focus switches border to `#292524` with no harsh glow, utilizing a 1px solid ring.
- **Currency Entry Inputs:** Oversized numeric readout (`headline-xl`), right-aligned or centered, using JetBrains Mono with currency symbols anchored statically in muted tone `#78716C`.

### Chips & Status Badges
- Ultra-compact padding (4px vertical, 10px horizontal), pill radius (`9999px`).
- Monospaced 11px uppercase typography (`label-sm`).
- Pastels dictate status without alarming the user:
  - *Completed Sale:* Sage tint `#E8EFEA` with `#2B4E3B` dot and text.
  - *Pending Loan:* Peach tint `#F8EDE8` with `#693A27` dot and text.
  - *Terminal Closed:* Rose tint `#F6EBEA` with `#672923` dot and text.

### Lists & Transaction Rows
- Compact 56px height per row.
- Left edge: circular pastel-tinted icon container (36px) matching the category type.
- Center: bold item title with light sub-label timestamp.
- Right edge: mono-aligned numeric amounts, colored `#1C1917` for standard line items, `#6B8E7B` for received amounts, and `#B86B64` for subtractions/refunds.

### Checkboxes & Radio Controls
- Rounded geometry (4px for checkboxes, 50% for radios).
- Inactive state: `#FAF7F2` surface, 1.5px border `#D7CCBF`.
- Selected state: `#292524` fill with `#FAF7F2` checkmark indicator. No high-saturation primary blues.